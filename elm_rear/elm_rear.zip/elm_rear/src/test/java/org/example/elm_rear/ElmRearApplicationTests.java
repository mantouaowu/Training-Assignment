package org.example.elm_rear;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ElmRearApplicationTests {

    @Test
    void contextLoads() {
    }

}
