package com.example.elm_rear;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ElmRearApplication {
    public static void main(String[] args) {
        SpringApplication.run(ElmRearApplication.class, args);
    }
}
