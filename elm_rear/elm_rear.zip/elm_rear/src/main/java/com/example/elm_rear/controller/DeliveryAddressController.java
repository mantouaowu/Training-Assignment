package com.example.elm_rear.controller;

import com.example.elm_rear.po.DeliveryAddress;
import com.example.elm_rear.service.DeliveryAddressService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/deliveryAddress")
public class DeliveryAddressController {
    @Autowired
    private DeliveryAddressService deliveryAddressService;

    // 查询用户所有配送地址
    @GetMapping("/user/{userId}")
    public ResponseEntity<List<DeliveryAddress>> listDeliveryAddressByUserId(@PathVariable String userId) {
        List<DeliveryAddress> addresses = deliveryAddressService.listDeliveryAddressByUserId(userId);
        return ResponseEntity.ok(addresses);
    }

    // 根据ID查询配送地址
    @GetMapping("/{daId}")
    public ResponseEntity<?> getDeliveryAddressById(@PathVariable Long daId) {
        DeliveryAddress address = deliveryAddressService.getDeliveryAddressById(daId);
        if (address == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(address);
    }

    // 新增配送地址
    @PostMapping
    public ResponseEntity<DeliveryAddress> saveDeliveryAddress(@RequestBody DeliveryAddress deliveryAddress) {
        DeliveryAddress saved = deliveryAddressService.saveDeliveryAddress(deliveryAddress);
        return ResponseEntity.ok(saved);
    }

    // 更新配送地址
    @PutMapping("/{daId}")
    public ResponseEntity<?> updateDeliveryAddress(
            @PathVariable Long daId,
            @RequestBody DeliveryAddress deliveryAddress) {
        if (!daId.equals(deliveryAddress.getDaId())) {
            return ResponseEntity.badRequest().body("地址ID不匹配");
        }
        DeliveryAddress updated = deliveryAddressService.updateDeliveryAddress(deliveryAddress);
        return ResponseEntity.ok(updated);
    }

    // 删除配送地址
    @DeleteMapping("/{daId}")
    public ResponseEntity<?> removeDeliveryAddress(@PathVariable Long daId) {
        deliveryAddressService.removeDeliveryAddress(daId);
        return ResponseEntity.ok().build();
    }
}