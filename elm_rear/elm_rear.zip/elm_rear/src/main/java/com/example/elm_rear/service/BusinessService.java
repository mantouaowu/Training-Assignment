package com.example.elm_rear.service;

import com.example.elm_rear.po.Business;
import com.example.elm_rear.dao.BusinessDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BusinessService {
    @Autowired
    private BusinessDao businessDao;

    public List<Business> listBusinessByOrderTypeId(Integer orderTypeId) {
        return businessDao.findByOrderTypeId(orderTypeId);
    }

    public Business getBusinessById(Long businessId) {
        return businessDao.findById(businessId).orElse(null);
    }
}