package com.example.elm_rear.po;

import jakarta.persistence.*;

@Entity
@Table(name = "delivery_address")
public class DeliveryAddress {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long daId;       // 配送地址编号

    @Column(nullable = false)
    private String userId;    // 用户ID

    @Column(nullable = false)
    private String contactName;  // 联系人姓名

    @Column(nullable = false)
    private Integer contactSex;  // 联系人性别

    @Column(nullable = false)
    private String contactTel;   // 联系人电话

    @Column(nullable = false)
    private String address;      // 送货地址

    // Getters and Setters
    public Long getDaId() {
        return daId;
    }

    public void setDaId(Long daId) {
        this.daId = daId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getContactName() {
        return contactName;
    }

    public void setContactName(String contactName) {
        this.contactName = contactName;
    }

    public Integer getContactSex() {
        return contactSex;
    }

    public void setContactSex(Integer contactSex) {
        this.contactSex = contactSex;
    }

    public String getContactTel() {
        return contactTel;
    }

    public void setContactTel(String contactTel) {
        this.contactTel = contactTel;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}