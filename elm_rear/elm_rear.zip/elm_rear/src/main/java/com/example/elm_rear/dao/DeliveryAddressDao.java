package com.example.elm_rear.dao;

import com.example.elm_rear.po.DeliveryAddress;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface DeliveryAddressDao extends JpaRepository<DeliveryAddress, Long> {
    // 根据用户ID查询所有配送地址
    List<DeliveryAddress> findByUserId(String userId);

    // 根据用户ID和地址ID查询特定配送地址
    DeliveryAddress findByUserIdAndDaId(String userId, Long daId);
}