package com.example.elm_rear.service;

import com.example.elm_rear.po.DeliveryAddress;
import com.example.elm_rear.dao.DeliveryAddressDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DeliveryAddressService {
    @Autowired
    private DeliveryAddressDao deliveryAddressDao;

    // 根据用户ID查询所有配送地址
    public List<DeliveryAddress> listDeliveryAddressByUserId(String userId) {
        return deliveryAddressDao.findByUserId(userId);
    }

    // 根据送货地址编号查询送货地址
    public DeliveryAddress getDeliveryAddressById(Long daId) {
        return deliveryAddressDao.findById(daId).orElse(null);
    }

    // 新增送货地址
    public DeliveryAddress saveDeliveryAddress(DeliveryAddress deliveryAddress) {
        return deliveryAddressDao.save(deliveryAddress);
    }

    // 更新送货地址
    public DeliveryAddress updateDeliveryAddress(DeliveryAddress deliveryAddress) {
        return deliveryAddressDao.save(deliveryAddress);
    }

    // 删除送货地址
    public void removeDeliveryAddress(Long daId) {
        deliveryAddressDao.deleteById(daId);
    }
}